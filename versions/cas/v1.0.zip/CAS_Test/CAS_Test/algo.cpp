#include "algo.h"

ll Algo::abs(ll x) { return x < 0 ? -x : x; }
ll Algo::gcd(ll x, ll y) { return y ? gcd(y, x % y) : x; }
ll Algo::lcm(ll x, ll y) { return x / gcd(x, y) * y; }

std::map<ll, ll> Algo::factorize(ll x) {
    std::map<ll, ll> res;

    for (ll i = 2; i * i <= x; ++i) if (x % i == 0) {
        ll tmp = 0;
        while (x % i == 0) {
            x /= i;
            ++tmp;
        }
        res[i] = tmp;
    }
    if (x > 1) res[x] = 1;
    return res;
}

ll Algo::mu(ll x) {
    if (x == 1) return 1;
    auto M = factorize(x);
    for (auto& x : M) if (x.second > 1) return 0;
    if (M.size() % 2 == 0) return 1;
    else return -1;
}