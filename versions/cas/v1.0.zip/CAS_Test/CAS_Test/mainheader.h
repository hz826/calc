#pragma once

#include <iostream>
#include <cmath>
#include <vector>
#include <map>
#include <complex>

typedef long long ll;