#include "factor.h"

Base operator | (Base X, Base Y) {
    Base Z;
    auto i = X.begin(), j = Y.begin();
    while (i != X.end() || j != Y.end()) {
        if (j == Y.end()) { Z[i->first] = i->second;  ++i; }
        else if (i == X.end()) { Z[j->first] = j->second;  ++j; }

        else if (i->first < j->first) { Z[i->first] = i->second;  ++i; }
        else if (i->first > j->first) { Z[j->first] = j->second;  ++j; }
        else { Z[i->first] = Algo::lcm(i->second, j->second);  ++i;  ++j; }
    }
    return Z;
}

ll Base::encode(Factor F) {
    ll res = 0;
    for (auto it = begin(); it != end(); ++it) {
        res = res * it->second + ((F.find(it->first) == F.end()) ? 0 : F[it->first]);
        if (F[it->first] >= it->second) throw "invalid Factor";
    }
    return res;
}

Factor Base::decode(ll x) {
    Factor F;
    for (auto it = rbegin(); it != rend(); ++it) {
        ll tmp = x % it->second;
        x /= it->second;
        if (tmp > 0) F[it->first] = tmp;
    }
    if (x) throw "invalid Factor";
    return F;
}

double Base::getDouble(Factor F) {
    double res = 1.0;
    for (const auto &x : F) {
        auto it = find(x.first);
        if (it == end()) throw "invalid Factor";
        std::pow(x.first, x.second / it->second);
    }
    return res;
}