#include "rational.h"

Rational operator + (Rational A, Rational B) {
    Rational C;
    C.q = Algo::lcm(A.q, B.q);
    C.p = A.p * (C.q / A.q) + B.p * (C.q / B.q);
    C.simp();
    return C;
}

Rational operator - (Rational A, Rational B) {
    B.p = -B.p;
    return A + B;
}

Rational operator * (Rational A, Rational B) {
    Rational R(A.p * B.p, A.q * B.q);
    R.simp();
    return R;
}

Rational operator / (Rational A, Rational B) {
    Rational R(A.p * B.q, A.q * B.p);
    R.simp();
    return R;
}

bool operator < (Rational A, Rational B) {//ap/aq < bp/bq
    return A.p * B.q < B.p* A.q;
}

bool operator == (Rational A, Rational B) {
    return A.p * B.q == B.p * A.q;
}

void Rational::simp() {
    if (q == 0) throw "Rational.simp : divided by zero";
    ll g = Algo::gcd(p, q);
    p /= g;  q /= g;
    if (q < 0) { p = -p;  q = -q; }
}

ll Rational::mod() {
    ll m = p / q;  p %= q;
    if (p < 0) p += q, --m;
    return m;
}

double Rational::getDouble() { return 1.0 * p / q; }
void Rational::print() { std::cout << p << "/" << q; }