﻿#include "mainheader.h"

int main() {
    std::cout << "Hello World!\n"; 
}