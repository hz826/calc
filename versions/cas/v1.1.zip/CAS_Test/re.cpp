#include<iostream>
using namespace std;
class base1{
	public:
		void display()const{cout<<"b";}
};
class base2:public base1{
	public:
	void display()const{cout<<"a";}
};
int main(){
	base1 a;
	base2 b;
	a.display();
	b.display();
}
