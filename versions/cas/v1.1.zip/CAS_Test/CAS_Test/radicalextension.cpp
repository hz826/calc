#include "radicalextension.h"

void RadicalExtension::changebase(Base nbase) {
    Values nvalue;
    for (auto v : value) {
        nvalue[nbase.encode(base.decode(v.first))] = v.second;
    }
}

RadicalExtension operator + (RadicalExtension A, RadicalExtension B) {
    RadicalExtension C;
    C.base=A.base|B.base;
    A.changebase(C.base);
    B.changebase(C.base);
    for(auto i=A.value.begin();i!=A.value.end();i++)
	{
	for(auto j=B.value.begin();j!=B.value.end();j++)
	{		
    if(i->first==j->first)
	{
    C.value[i->first]=A.value[i->first]+B.value[j->first];
    }
    }
	}
    return C;
}

RadicalExtension operator - (RadicalExtension A, RadicalExtension B) {
    RadicalExtension C;
    C.base=A.base|B.base;
    A.changebase(C.base);
    B.changebase(C.base);
    for(auto i=A.value.begin();i!=A.value.end();i++)
	{
	for(auto j=B.value.begin();j!=B.value.end();j++)
	{		
    if(i->first==j->first)
	{
    C.value[i->first]=A.value[i->first]+B.value[j->first];
    }
    }
	}
    return C;
}
RadicalExtension operator * (RadicalExtension A, RadicalExtension B) {
    RadicalExtension C;
    C.base=A.base|B.base;
    for(auto i:A.value)
	{
    	for(auto j:B.value)
		{
    		Factor F1,F2,F3;
    		F1=A.base.decode(i.first);
    		F2=B.base.decode(j.first);//�ֱ�decodeAB��Ӧvalue��code 
    		for(auto i1=F1.begin();i1!=F1.end();i1++){
    			for(auto j1=F2.begin();j1!=F2.end();j1++){
    			if(F1[i1->first]==F2[j1->first]&&A.base[i1->first]==B.base[j1->first]){//ͨ��base��factor�����ֳ˷��� 
    			ll m=i1->first*j1->first;//����encode��encodeһ��factor�����Բ����µ�factor 
    			ll z=F1[i1->first];
    			F3[m]=z;
    			break;
    		}
    		
    		else{
				for(i1;i1!=F1.end();i1++){
				for(j1;j1!=F2.end();j1++){
				F3[i1->first]=F1[i1->first];
				F3[j1->first]=F2[j1->first];//"�Ǿ͵õ���һ����factors {(3,1) (5,2)}"
				ll n=C.base.encode(F3);
				C.value[n]=i.second*j.second;
				C.simp();
			}
				}
				}
			
    		}

    	}
    }
}
    
    return C;

}
RadicalExtension operator / (RadicalExtension A, RadicalExtension B) {
    RadicalExtension C;
    return C;
}

void RadicalExtension::simp() {
    ll now = 1;
    Base nbase;
    for (auto B : base) {
        ll g = B.second;
        for (const auto &v : value) {
            ll x = v.first / now % B.second;
            g = Algo::gcd(g, x);
        }
        if (g < B.second) nbase[B.first] = B.second / g;
        now *= B.second;
    }
    changebase(nbase);
 }

RadicalExtension::RadicalExtension() {}

RadicalExtension::RadicalExtension(Rational A) {//A
    Factor F;
    value[base.encode(F)] = A;
}

RadicalExtension::RadicalExtension(ll A, Rational B) {
    /*
        A^(p/q) = (a1^b1*a2^b2*...an^bn)^B
                = a1^b1B*a2^b2B*...
                = alpha * a1^b1' * a2^b2' * ...
    */
    Rational alpha(1);
    Factor F;
    std::map<ll, ll> fact = Algo::factorize(A);

    for (const auto& x : fact) {//x.fi ^ (x.se * B) = x.fi ^ tmp = 
        Rational tmp = B * Rational(x.second);
        ll m = tmp.mod();
        F[x.first] = tmp.p;
        base[x.first] = tmp.q;
        alpha = alpha * Algo::qpow(Rational(x.first), m);
    }

    value[base.encode(F)] = alpha;
}

RadicalExtension::RadicalExtension(Rational A, Rational B) {//(ap/aq)^B = ap^B * aq ^(-B)
    *this = RadicalExtension(A.p,B) * RadicalExtension(A.q,Rational(0)-B);
}

double RadicalExtension::getDouble() {
    double res = 0;
    for (auto &x : value) {
        res += x.second.getDouble() * base.getDouble(base.decode(x.first));
    }
    return res;
}

void RadicalExtension::print() {
	for(auto i:value){
	
	}
}
