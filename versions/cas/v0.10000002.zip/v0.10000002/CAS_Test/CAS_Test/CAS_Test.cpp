#include "mainheader.h"
#include "rational.h"
#include "radicalextension.h"
#include<iostream>
using namespace std;

int main() {
    std::cout << "Hello World!\n";
	Rational E(1); 
    RadicalExtension A(2);
    RadicalExtension B(3);
    RadicalExtension C(2);
    }

