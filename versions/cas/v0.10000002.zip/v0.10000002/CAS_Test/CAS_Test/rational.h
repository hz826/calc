#pragma once

#include "mainheader.h"
#include "algo.h"

class Rational {//��������
private:
public:
    ll p, q;
    Rational() : p(0), q(1) {}
    Rational(ll p) : p(p), q(1) {}
    Rational(ll p, ll q) : p(p), q(q) {}
    Rational(const Rational& R) : p(R.p), q(R.q) {}

    friend Rational operator + (Rational A, Rational B);
    friend Rational operator - (Rational A, Rational B);
    friend Rational operator * (Rational A, Rational B);
    friend Rational operator / (Rational A, Rational B);
    friend bool operator <  (Rational A, Rational B);
    friend bool operator == (Rational A, Rational B);

    void simp();//����ͨ��
    ll mod();//��Ϊ�������������������
    double getDouble();
    void print();
};