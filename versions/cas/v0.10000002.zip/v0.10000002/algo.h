#pragma once

#include "mainheader.h"

class Algo {//�㷨�࣬���г�Ա��Ϊstatic
public:
    static ll abs(ll x);//����ֵ
    static ll gcd(ll x, ll y);//���Լ��
    static ll lcm(ll x, ll y);//��С������
	static void swap(std::vector<ll>& A,ll a,ll b){
    int temp=A[a];
    A[a]=A[b];
    A[b]=temp;
	}
    static std::map<ll, ll> factorize(ll x);
    /*
        �ֽ����������Ժ����ø���Ч��pollard's rho �㷨������map<�������η�>
        factorize(24) = map { (2,3) , (3,1) };
    */


    //����һЩδ֪��ԭ��template����ֻ����ͷ�ļ���ʵ��
    template<typename T>
    static T qpow(T a, ll x) {//a^x
        bool flag = false;
        if (x < 0) x = -x, flag = true;
        T r = T(1);
        for (; x; x >>= 1) {
            if (x & 1) r = r * a;
            a = a * a;
        }
        if (flag) r = T(1) / r;
        return r;
    }
    /*
        ����ĳ������Ԫ�ص������η�
        qpow(Rational(-2,3), -3) = Rational(-27,8);
    */
	template<typename T>
	static void get(std::vector<T>B,std::vector<std::vector<T>>&A,ll start=0){
	int col=B.size();	
    if(start==col-1){
	A.push_back(B);
	}
	else{
	for(auto j=start;j<col;j++)
	{
	swap(B,j,start);
    get(B,A,start+1);
    swap(B,j,start);	
	}	
	}
	}
    static bool even(int nixu){return((nixu&1)==0);}
    static bool even2(std::vector<ll>&B){
	int nixu=0;
	for(int i=0;i<(int)B.size();i++){
		for(int j=i+1;j<(int)B.size();j++){
			if(B[i]>B[j]){
				nixu++;
			}
		}
	}
	return even(nixu);
	}
    template<typename T>
    static T det(std::vector< std::vector<T> >& R) {
	std::vector<T>B;
	for(int z=0;z<(int)R.size();z++){
	B.push_back(z);
	}
	//you shuru de nage juzhen;
	std::vector<std::vector<T>>A;
	std::vector<T>A_element;
	get(B,A);
	ll sum=0,result=0;
	for(int i=0;i<(int)A.size();i++){
	A_element=A[i];
	int q=even2(A_element)?1 : (-1);
	result=q;
	int row=0;
	for (int j = 0; j < (int)A_element.size();j++){
		int col=A_element[j];
		result*=R[row++][col];
	}
	sum+=result;
	}

	return sum;
	}
    template<typename T>
    static void solve(std::vector< std::vector<T> >& A, std::vector<T>& B) {//�ÿ���Ĭ����ⷽ��
		if(det(A)!=0){
		int m=det(A);
		std::vector<T>list;
		std::vector< std::vector<T> >C;
		C=A;
		for(int i=0;i<(int)A.size();i++){
			for(int j=0;j<(int)A.size();j++){
				A[j][i]=B[j];
			}
			list.push_back(det(A));
			A=C;			
		}
		for(int n=0;n<(int)A.size();n++){
			std::cout<<"��Ϊ"<<(double)list[n]/m; 
		}
	}
	else{
		//throw "multiply solution";
	}
}
};
