#include "radicalextension.h"

void RadicalExtension::changebase(Base nbase) {
    Values nvalue;
    for (auto v : value) {
        nvalue[nbase.encode(base.decode(v.first))] = v.second;
    }
}

RadicalExtension operator + (RadicalExtension A, RadicalExtension B) {
    RadicalExtension C;
    C.base=A.base|B.base;
    A.changebase(C.base);
    B.changebase(C.base);
	auto i=A.base.begin();auto j=B.base.begin();
	for(i;i!=A.base.end();i++){
		for(j;j!=B.base.end();j++){
			if(i->first==j->first){
				if(i->second==j->second){
				Factor F;
				F[i->first]=1;
				ll m=A.base.encode(F);
				ll n=B.base.encode(F);	
				C.value[C.base.encode(F)]=m+n;
				break;	
				}
			}
		}
	} 
    return C;
}

RadicalExtension operator - (RadicalExtension A, RadicalExtension B) {
    RadicalExtension C;
    C.base=A.base|B.base;
    A.changebase(C.base);
    B.changebase(C.base);
    auto i=A.base.begin();auto j=B.base.begin();
	for(i;i!=A.base.end();i++){
		for(j;j!=B.base.end();j++){
			if(i->first==j->first){
				if(i->second==j->second){
				Factor F;
				F[i->first]=1;
				ll m=A.base.encode(F);
				ll n=B.base.encode(F);	
				C.value[C.base.encode(F)]=m+n;
				for(auto z:C.value){
				C.base.decode(z.first);
				}
				break;
				}
			}
		}
	} 
    return C;
}

RadicalExtension operator * (RadicalExtension A, RadicalExtension B) {
    RadicalExtension C;
    A.base|B.base;
    auto i=A.base.begin();auto j=B.base.begin();
   	for(i;i!=A.base.end();i++){
		for(j;j!=B.base.end();j++){
			if(i->first==j->first){
				if(i->second==j->second){
				ll m=A.base.encode(A.base);
				ll n=B.base.encode(B.base);	
				C.value[i->first]=m*n;
				break;
    return C;
}
}
}
}
}
RadicalExtension operator / (RadicalExtension A, RadicalExtension B) {
    RadicalExtension C;
    return C;
}

void RadicalExtension::simp() {
    ll now = 1;
    Base nbase;
    for (auto B : base) {
        ll g = B.second;
        for (const auto &v : value) {
            ll x = v.first / now % B.second;
            g = Algo::gcd(g, x);
        }
        if (g < B.second) nbase[B.first] = B.second / g;
        now *= B.second;
    }
    changebase(nbase);
 }

RadicalExtension::RadicalExtension() {}

RadicalExtension::RadicalExtension(Rational A) {//A
    Factor F;
    value[base.encode(F)] = A;
}

RadicalExtension::RadicalExtension(ll A, Rational B) {
    /*
        A^(p/q) = (a1^b1*a2^b2*...an^bn)^B
                = a1^b1B*a2^b2B*...
                = alpha * a1^b1' * a2^b2' * ...
    */
    Rational alpha(1);
    Factor F;
    std::map<ll, ll> fact = Algo::factorize(A);

    for (const auto& x : fact) {//x.fi ^ (x.se * B) = x.fi ^ tmp = 
        Rational tmp = B * Rational(x.second);
        ll m = tmp.mod();
        F[x.first] = tmp.p;
        base[x.first] = tmp.q;
        alpha = alpha * Algo::qpow(Rational(x.first), m);
    }

    value[base.encode(F)] = alpha;
}

RadicalExtension::RadicalExtension(Rational A, Rational B) {//(ap/aq)^B = ap^B * aq ^(-B)
    *this = RadicalExtension(A.p,B) * RadicalExtension(A.q,Rational(0)-B);
}

double RadicalExtension::getDouble() {
    double res = 0;
    for (auto x : value) {
        res += x.second.getDouble() * base.getDouble(base.decode(x.first));
    }
    return res;
}

void RadicalExtension::print() {

}
