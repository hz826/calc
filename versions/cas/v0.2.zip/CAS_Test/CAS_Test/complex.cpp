#include "complex.h"

Complex::Complex() {
}

Complex::Complex(Rational R) {
	(*this)[Rational(0)] = R;
}

Complex Complex::exp(Rational alpha) {
	Complex res;
	res[alpha] = 1;
	return res;
}

Complex Complex::sin(Rational alpha) {
	return cos(Rational(1,2) - alpha);
}

Complex Complex::cos(Rational alpha) {
	return (exp(alpha)+exp(Rational(0) - alpha)) * Rational(1, 2);
}

Complex Complex::sin(ll deg) {
	return sin(Rational(deg, 180));
}

Complex Complex::cos(ll deg) {
	return cos(Rational(deg, 180));
}

Complex operator + (Complex A, Complex B) {
	/*std::cout << "+" << std::endl;
	std::cout << "A  ";  A.printexp();  std::cout << std::endl;
	std::cout << "B  ";  B.printexp();  std::cout << std::endl;*/
	Complex C;
	for (auto &x : A) C[x.first] = x.second;
	for (auto &y : B) C[y.first] = C[y.first] + y.second;
	//std::cout << "C  ";  C.printexp();  std::cout << std::endl << std::endl;
	C.simp();
	//std::cout << "C  ";  C.printexp();  std::cout << std::endl << std::endl;
	return C;
}

Complex operator - (Complex A, Complex B) {
	Complex C;
	for (auto& x : A) C[x.first] = x.second;
	for (auto& y : B) C[y.first] = C[y.first] - y.second;
	C.simp();
	return C;
}

Complex operator * (Complex A, Complex B) {
	/*std::cout << "*" << std::endl;
	std::cout << "A  ";  A.printexp();  std::cout << std::endl;
	std::cout << "B  ";  B.printexp();  std::cout << std::endl;*/
	Complex C;
	for (auto& x : A) for (auto& y : B) C[x.first + y.first] = C[x.first + y.first] + x.second * y.second;
	//std::cout << "C  ";  C.printexp();  std::cout << std::endl << std::endl;
	C.simp();
	//std::cout << "C  ";  C.printexp();  std::cout << std::endl << std::endl;
	return C;
}

void Complex::simp() {
	for (auto it = begin(); it != end();) {
		Rational tmp = it->first + Rational(1, 2);
		ll m = tmp.mod();
		tmp = tmp - Rational(1, 2);

		if (m != 0) {
			if (m % 2 == 0) (*this)[tmp] = (*this)[tmp] + it->second;
			else (*this)[tmp] = (*this)[tmp] - it->second;
			it = erase(it);
		}
		else ++it;
	}
	for (auto it = begin(); it != end();) {
		Rational tmp = it->first;
		if (tmp == Rational(-1,3)) {
			auto itt = find(Rational(1, 3));
			if (itt != end() && itt->second == it->second) {
				(*this)[Rational(0)] = (*this)[Rational(0)] + Rational(2) * it->second * Rational(1, 2);//cos(30)=1/2
				erase(itt);
				it = erase(it);
				continue;
			}
		}
		if (it->second == Rational(0)) {
			it = erase(it);
			continue;
		}
		++it;
	}
}

RComplex::RComplex() : p(0), q(1) {
}

RComplex::RComplex(SPoly p, SPoly q,ll base) : p(p), q(q), base(base) {
	/*std::cout << "<>" << std::endl;
	std::cout << "p  ";  p.printexp();  std::cout << std::endl;
	std::cout << "q  ";  q.printexp();  std::cout << std::endl;*/
	if (base > 2) cyc = SPoly::cyclotomic(base);
	simp();
	/*std::cout << "p  ";  p.printexp();  std::cout << std::endl;
	std::cout << "q  ";  q.printexp();  std::cout << std::endl;
	std::cout << "<>" << std::endl;*/
}

RComplex::RComplex(Rational R) : p(R), q(1), base(1) {
}

RComplex RComplex::sin(Rational alpha) {
	return cos(Rational(1, 2) - alpha);
}

RComplex RComplex::cos(Rational alpha) {//\alpha * pi = \alpha/2 * 2pi
	alpha = alpha / 2;
	alpha.mod();
	RComplex res(Rational(0), Rational(1), alpha.q);
	res.p[alpha.p] = res.p[alpha.p] + Rational(1, 2);
	res.p[alpha.q] = res.p[alpha.q] + Rational(1, 2);
	return res;
}

RComplex RComplex::tan(Rational alpha) {
	return sin(alpha) / cos(alpha);
}

RComplex RComplex::sin(ll deg) {
	return sin(Rational(deg, 180));
}

RComplex RComplex::cos(ll deg) {
	return cos(Rational(deg, 180));
}

RComplex RComplex::tan(ll deg) {
	return tan(Rational(deg, 180));
}

RComplex operator + (RComplex A, RComplex B) {
	
}

RComplex operator - (RComplex A, RComplex B) {
	
}

RComplex operator * (RComplex A, RComplex B) {
	
}

RComplex operator / (RComplex A, RComplex B) {
	
}

void RComplex::simp() {
	/*std::cout << "simp!" << std::endl;
	std::cout << "p  ";  p.printexp();  std::cout << std::endl;
	std::cout << "q  ";  q.printexp();  std::cout << std::endl;*/

	p.simp();
	q.simp();
	if (q.size() == 0) throw "RComplex.simp : divided by zero";
	if (p.size() == 0) {
		q.clear();
		q[Rational(0)] = 1;
	}

	Complex pp = p, qq = q, g;

	if (pp.rbegin()->first < qq.rbegin()->first) swap(pp, qq);
	while (qq.size() > 0) {
		/*std::cout << "pp  ";  pp.printexp();  std::cout << std::endl;
		std::cout << "qq  ";  qq.printexp();  std::cout << std::endl;*/
		Rational d = pp.rbegin()->first - qq.rbegin()->first;
		Rational a = pp.rbegin()->second / qq.rbegin()->second;
		Complex tmp = (d == Rational(0)) ? Complex::exp(0) : Complex::exp(d) + Complex::exp(Rational(0) - d);
		
		pp = pp - qq * tmp * a;
		
		if (pp.size() == 0 || pp.rbegin()->first < qq.rbegin()->first) swap(pp, qq);
	}
	swap(g, pp);
	pp.clear();  qq.clear();

	while (p.size() > 0) {
		Rational d = p.rbegin()->first - g.rbegin()->first;
		Rational a = p.rbegin()->second / g.rbegin()->second;
		Complex tmp = (d == Rational(0)) ? Complex::exp(0) : Complex::exp(d) + Complex::exp(Rational(0) - d);
		p = p - g * tmp * a;
		pp[d] = pp[Rational(0) - d] = a;
	}

	while (q.size() > 0) {
		Rational d = q.rbegin()->first - g.rbegin()->first;
		Rational a = q.rbegin()->second / g.rbegin()->second;
		Complex tmp = (d == Rational(0)) ? Complex::exp(0) : Complex::exp(d) + Complex::exp(Rational(0) - d);
		q = q - g * tmp * a;
		qq[d] = qq[Rational(0) - d] = a;
	}

	swap(p, pp);
	swap(q, qq);

	ll lcm = 1;
	for (auto& x : p) lcm = Algo::lcm(lcm, x.second.q);
	for (auto& y : q) lcm = Algo::lcm(lcm, y.second.q);
	for (auto& x : p) x.second = x.second * lcm;
	for (auto& y : q) y.second = y.second * lcm;

	ll gcd = 0;
	for (auto& x : p) gcd = Algo::gcd(gcd, x.second.p);
	for (auto& y : q) gcd = Algo::gcd(gcd, y.second.p);
	for (auto& x : p) x.second = x.second / gcd;
	for (auto& y : q) y.second = y.second / gcd;
}

std::complex<double> RComplex::getDouble() {
	std::complex<double> wn = std::exp(std::complex<double>(0, 2.0 * acos(-1) / base));
	return p.getDouble(wn) / q.getDouble(wn);
}

void RComplex::printexp() {
	char s[100];
	std::sprintf(s,"w_{%d}",base);
	std::cout << "(";
	p.print(s);
	std::cout << ")";
	std::cout << " / ";
	std::cout << "(";
	q.print(s);
	std::cout << ")";
}

void RComplex::printtrig(SPoly &p) {
	bool fi = false;
	for (auto& x : p) {
		if (Rational(0) < x.first) break;
		if (fi) std::cout << " + ";  else fi = true;
		if (x.first == Rational(0)) {
			x.second.print();
			continue;
		}
		auto it = p.find(-x.first);
		if (it == p.end()) throw "printtrig error!";
		else if (x.second == it->second) {
			(x.second * 2).print();
			std::cout << "*cos(";
			Rational(x.first * (-360),base).print();
			std::cout << "��)";
		}
		else throw "printtrig error!";
	}
}

void RComplex::printtrig() {
	std::cout << "[";
	printtrig(p);
	std::cout << "]";
	std::cout << " / ";
	std::cout << "[";
	printtrig(q);
	std::cout << "]";
}