#pragma once

#include "mainheader.h"
#include "poly.h"


class RComplex {
public:
	SPoly p, q, cyc;//p = \sum e^{\aplha \pi i}, where -\frac12 < \alpha < \frac12
    ll base;

    RComplex();
    RComplex(SPoly p,SPoly q,ll base);
    RComplex(Rational R);
    static RComplex sin(Rational alpha);
    static RComplex cos(Rational alpha);
    static RComplex tan(Rational alpha);
    static RComplex sin(ll deg);
    static RComplex cos(ll deg);
    static RComplex tan(ll deg);

    friend RComplex operator + (RComplex A, RComplex B);
    friend RComplex operator - (RComplex A, RComplex B);
    friend RComplex operator * (RComplex A, RComplex B);
    friend RComplex operator / (RComplex A, RComplex B);

    void simp();//����ͨ��
    std::complex<double> getDouble();
    void printexp();
    void printtrig();
    void printtrig(SPoly &p);
};