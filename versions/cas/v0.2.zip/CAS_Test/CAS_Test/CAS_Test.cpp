﻿#include "mainheader.h"
#include "poly.h"
#include "complex.h"

int main() {
    try {
        /*RComplex y = RComplex::cos(10) *RComplex::cos(10) + RComplex::cos(50) * RComplex::cos(50) - RComplex::sin(40) * RComplex::sin(80);

        y.printexp();    std::cout << std::endl;
        y.printtrig();   std::cout << std::endl;
        std::cout << "double : " << y.getDouble() << std::endl;*/
    }
    catch (const char* s) {
        std::cout << "error : " << s << std::endl;
    }
}