#pragma once

#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <complex>

typedef long long ll;