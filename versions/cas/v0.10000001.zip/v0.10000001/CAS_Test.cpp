#include "mainheader.h"
#include<iostream> 
#include "algo.h"
int main() {
    std::cout << "Hello Worlduy1\n"; 
    std::vector<std::vector<ll>>A(3,std::vector<ll>(3,1));
    std::cout<<Algo::det(A);
}
