#pragma once

#include <iostream>
#include <cmath>
#include <vector>
#include <map>

typedef long long ll;